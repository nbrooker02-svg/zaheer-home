# Ground Zero — FREE
### Your first Claude Code agent. Learn the system. Get useful help today.

---

## What This Is

This is **Ground Zero** — the free starter pack from Zaheer Studio. A minimal but fully working AI agent that runs locally on your machine using Claude Code.

**In 5 minutes you'll have:**
- A personal AI agent that remembers what you tell it
- A working knowledge of how AI agents are structured
- Enough understanding to decide if a paid pack is right for you

**What makes this different from just chatting with Claude:**
- Your agent has memory across sessions — no re-explaining yourself
- Your preferences get saved automatically as you work
- Notes, ideas, and tasks stay organized in files you own
- Everything runs on your machine — your data never leaves

---

## Folder Structure

```
Ground Zero/
│
├── CLAUDE.md                ← root, auto-loads in Claude Code
│
├── Core/                    ← YOUR personal files
│   ├── MEMORY.md           ← what your agent learns about you
│   └── NOTES.md             ← anything you want to track
│
└── Updates/                 ← instruction files
    ├── README.md            ← this file
    ├── ONBOARDING.md        ← first-time setup
    └── UPGRADE_PATH.md      ← paid packs catalog
```

**Only 2 files in Core.** Ground Zero is intentionally simple so you learn the system without overwhelm.

---

## Before You Start

You need:

- **Claude Code installed** — comes with Claude Pro
- **A Claude Pro account** — [claude.ai](https://claude.ai)
- **The ability to run Claude Code in this folder** — see setup instructions

New to Claude Code? Install it by running this in your terminal:
```
npm install -g @anthropic-ai/claude-code
```

Then open this folder in VS Code (or any terminal) and type `claude` to launch.

---

## Getting Started

1. **Open Claude Code** in this folder
2. **Type:** `yes` (your agent will detect you're new and launch onboarding)
3. **Answer 6 quick questions** — takes about 5 minutes
4. **Start asking for help**

That's it.

---

## What to Try First

Once you're through onboarding, try any of these:

**Ask it to help with work:**
> "Help me think through [something you're stuck on]"

**Draft something:**
> "Write me an email declining a meeting"

**Save an idea:**
> "Add this to my notes: I want to try [idea]"

**Learn something:**
> "Explain [complex topic] in simple terms"

**Teach it a preference:**
> "Remember that I prefer short responses"

---

## When to Upgrade

Ground Zero is great for general personal use. But if you find yourself wanting:

- Pre-built skills for your specific profession
- Context-aware workflows for repetitive tasks
- An agent that understands your industry's language and tools
- Monthly updates with new features

...then it's time to check out the **paid packs**.

Open `Updates/UPGRADE_PATH.md` to see what's available.

---

## What You Keep Even If You Upgrade

Everything. When you move to a paid pack, the system is the same — you just get way more pre-built intelligence. Your `Core/` folder logic stays yours, your preferences transfer easily, and the skills you learn here apply directly.

Ground Zero isn't a trial. It's a real working agent. It just doesn't come with the domain-specific intelligence the paid packs have.

---

## Support

- Questions: [support email]
- Community: [community link]
- Full pack catalog: [zaheer.studio/studio](https://zaheer.studio)

---

*From Zaheer Studio. Made for people who build things solo.*
