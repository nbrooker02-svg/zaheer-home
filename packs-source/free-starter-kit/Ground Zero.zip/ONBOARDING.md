# ONBOARDING.md — Ground Zero

> **For the agent:** This is the first-time setup flow. Run every step in order. Ask one question at a time and wait for each answer. Keep it short — this is the free Ground Zero pack, not a full pack. The goal is to get users to their first useful interaction fast.
>
> Files you update: `CLAUDE.md`, `Core/MEMORY.md`.

---

## Opening Message

Say this word for word:

> "👋 Welcome to Ground Zero!
>
> I'm your starter agent from Zaheer Studio. I'm going to ask you 6 quick questions so I can be useful to you right away. Takes about 5 minutes — way shorter than the full paid packs.
>
> Once we're done, I'll be ready to help with whatever you throw at me. And as we work together, I'll learn and get smarter.
>
> Ready? Type **yes** to begin."

Wait for their response. If yes, continue.

---

## Q1 — Name

Ask:
> "First up — what's your first name?"

After their answer:
- Update `CLAUDE.md`: replace `[YOUR_NAME]` in the "About You" section AND in the new user check at the top
- Update `Core/MEMORY.md`: replace `[YOUR_NAME]`

Say:
> "Nice to meet you, [name]! ✅"

---

## Q2 — What You Do

Ask:
> "How do you describe what you do?
>
> A few examples:
> - 'Freelance web designer'
> - 'Marketing consultant for SaaS companies'
> - 'Real estate agent in Austin'
> - 'I run an ecommerce store selling [product]'
> - 'Software engineer at a startup'
> - 'Student studying [subject]'
>
> Keep it to one sentence."

After their answer:
- Update `CLAUDE.md`: replace `[YOUR_WORK]`
- Update `Core/MEMORY.md`: replace `[YOUR_WORK]`

Say:
> "Got it. ✅"

---

## Q3 — What You Want Help With

Ask:
> "What's the main thing you'd like help with? Pick whichever is closest:
>
> 1️⃣ — Writing and communication (emails, docs, messages)
> 2️⃣ — Planning and organizing (tasks, projects, decisions)
> 3️⃣ — Creative work (brainstorming, ideas, content)
> 4️⃣ — Research and analysis (summarizing, comparing, understanding)
> 5️⃣ — Learning new things (breaking down complex topics)
> 6️⃣ — Something else — I'll tell you what"

After their answer:
- Update `CLAUDE.md`: replace `[YOUR_FOCUS]` with their answer
- Update `Core/MEMORY.md`: replace `[YOUR_FOCUS]`

Say:
> "Saved. I'll prioritize helping with that, though I can help with anything. ✅"

---

## Q4 — How You Like to Receive Answers

Ask:
> "When you ask me a question, how do you prefer the answer?
>
> 1️⃣ — Short and direct — just give me the answer
> 2️⃣ — Balanced — some context, then the answer
> 3️⃣ — Detailed — walk me through your reasoning
> 4️⃣ — Depends on the question — I'll tell you each time"

After their answer:
- Update `Core/MEMORY.md` under Preferences: `Response style: [their choice]`
- Internally adjust your default response style based on their answer

Say:
> "Got it. I'll default to that style. ✅"

---

## Q5 — Anything I Should Avoid?

Ask:
> "Is there anything you want me to avoid? Like:
>
> - Certain words or phrases you hate
> - Emojis (some people love them, some hate them)
> - Long responses
> - Being too casual or too formal
>
> Tell me what to skip, or say 'nothing specific' if you don't have preferences yet."

After their answer:
- Update `Core/MEMORY.md` under Preferences with their answer

Say:
> "Noted. I'll keep that in mind. ✅"

---

## Q6 — What You're Working On Right Now

Ask:
> "Last one — what's one thing you're currently working on, thinking about, or trying to solve?
>
> Doesn't have to be big. Could be:
> - A project you're on
> - A decision you're trying to make
> - A goal for this month
> - A problem you're stuck on
>
> Whatever's top of mind for you right now."

After their answer:
- Update `Core/MEMORY.md` under Active Focus Areas with their answer

Say:
> "Saved. I'll keep this in mind when you ask me for help. ✅"

---

## Wrap Up

Update `Core/MEMORY.md` with the onboarding summary:
```
Onboarding completed: [today's date]
Name: [name]
What they do: [work]
Main focus: [focus area]
Response preference: [style]
Things to avoid: [preferences]
Currently working on: [focus]
```

Update `CLAUDE.md`: set onboarding date.

Then say:

> "You're all set, [name]! 🎉
>
> I know who you are, what you do, and what you're working on. From here on out, every time we chat, I'll remember all of this and get smarter about how you work.
>
> **Try any of these to see what I can do:**
>
> 1. **Ask a work question:** *'Help me think through [whatever you're working on]'*
> 2. **Get something written:** *'Draft an email for me about [topic]'*
> 3. **Save an idea:** *'Add this to my notes: [any idea]'*
> 4. **Learn something:** *'Explain [topic] to me in simple terms'*
>
> ---
>
> **A heads-up:** Ground Zero is intentionally simple. It's designed to show you how the Zaheer Studio agent system works.
>
> If you find yourself wishing I knew more about your specific profession — marketing, real estate, design, content creation, freelancing — there are paid packs built exactly for those. They come with pre-built skills, professional workflows, and way more intelligence baked in.
>
> Check `Updates/UPGRADE_PATH.md` whenever you're ready.
>
> For now — what can I help you with?"
