# MEMORY.md — Ground Zero

Your agent reads this file at the start of every session. It's where your agent stores what it learns about you — preferences, decisions, corrections.

**Your agent updates this automatically** as you work together. The more you use it, the smarter it gets.

---

## About You

*Filled in during onboarding*

- **Name:** [YOUR_NAME]
- **What you do:** [YOUR_WORK]
- **What you want help with:** [YOUR_FOCUS]
- **Onboarding date:** [DATE]

---

## Preferences

*How you like to work. Your agent saves these as it learns.*

<!-- Examples your agent might add over time:
- Prefers short, direct answers over long explanations
- Wants bullet points instead of paragraphs
- Always mention trade-offs when suggesting options
- Never use em dashes
-->

---

## Corrections

*Things your agent got wrong and should never repeat.*

<!-- Examples:
- Suggested a tool I don't use — only suggest from what I've told you I use
- Used "utilize" when I said never use corporate speak
-->

---

## Decisions Made

*Key decisions so your agent doesn't ask about them again.*

<!-- Examples:
- My main priority this quarter is X
- I've decided to stop doing Y
- When I say "draft a reply," I mean keep it under 100 words
-->

---

## Context & Background

*Anything about your world that helps your agent be more useful.*

<!-- Examples:
- I run a team of 3 and we communicate mostly on Slack
- I'm based in the US Eastern time zone
- My biggest constraint right now is time, not money
-->

---

## Active Focus Areas

*What you're working on right now. Your agent uses this to tailor suggestions.*

<!-- Examples:
- Launching a new product in June
- Hiring my first employee
- Cutting expenses by 20% this quarter
-->
