# NOTES.md — Ground Zero

A running log of anything you want your agent to track — ideas, tasks, observations, decisions in progress.

**Your agent updates this automatically** when you say things like:
- "Add this to my notes: [whatever]"
- "Remind me about [thing]"
- "Save this idea: [thing]"

---

## Quick Notes

*Your agent adds new entries here automatically. Most recent at the top.*

<!-- Entries appear in this format:
### YYYY-MM-DD
- Note content
- Note content
-->

---

## Ideas to Explore

*Things you want to think about or research later.*

| Idea | Added | Notes |
|------|-------|-------|
| | | |

---

## Tasks & Reminders

*Things you need to do. Your agent can remind you about these.*

- [ ]

---

## Decisions in Progress

*Big calls you're working through. Your agent helps you think them through.*

<!-- Example:
### Should I hire a VA or a full-time assistant?
Started: 2026-04-15
Considerations: budget, hours needed, tasks to delegate
Current lean: VA for 10 hrs/week to start
-->

---

## Reference Info

*Anything you reference often — numbers, specs, links, etc.*

<!-- Example:
- Stripe dashboard: [link]
- Main email: [email]
- Accountant contact: [name and info]
-->

---

## How to Use This File

The best way to use NOTES.md is to just talk to your agent naturally:

> "Add to my notes: I'm thinking about switching to Ghost for my newsletter"

> "Remind me I need to renew my domain in November"

> "Save this quote: [paste quote]"

Your agent figures out where each thing belongs and files it correctly. You don't need to edit this file manually unless you want to.
