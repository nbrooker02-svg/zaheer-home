# UPGRADE_PATH.md — Ground Zero

You've got Ground Zero running. Now here's where it gets real.

---

## Why Upgrade?

Ground Zero is a generic agent — it knows YOU but it doesn't know your profession's specific workflows, tools, or language. Paid packs come pre-built with that intelligence.

Think of it this way:

**Ground Zero:** A smart assistant who just met you.
**Paid pack:** A smart assistant who already has 10 years of experience in your specific field.

Same system. Way more firepower.

---

## What You Get With Any Paid Pack

Every paid pack includes:

- **Pre-built domain expertise** — your agent already knows your profession's best practices
- **Specialized skills** — invoke-by-name workflows for common tasks in your field
- **Industry-specific onboarding** — asks the right questions to set you up right
- **Professional workflows** — proven operating rhythms for your work
- **Monthly updates** — new skills and refinements added regularly
- **Priority support** — direct line when you need help

---

## The Current Pack Catalog

### 🏗️ Ship Stack — AI App Builder Agent
**For:** Developers, founders, makers building web apps
**Price:** $49 one-time or included in Studio subscription

Your AI co-builder. Guides you through planning, building, and shipping web apps in 48 hours. Pre-configured with the full modern stack (React, Vercel, Stripe, Anthropic). Includes business rules that keep you focused, an agent-creator skill that builds other agents, and full onboarding that captures your tech preferences.

**Best for:** Solo founders and indie hackers who want to ship apps fast.

---

### 📣 One-Person Marketing Agent
**For:** Solopreneurs, creators, small business owners handling their own marketing
**Price:** $49 one-time or included in Studio subscription

Your marketing brain. Captures your voice through samples, learns your audience and content pillars, then turns one idea into a week of on-brand content across every platform you use. Includes the Content Repurposer skill that transforms newsletters into full content calendars.

**Best for:** Anyone doing their own marketing who's tired of generic AI-written posts.

---

### 🏡 Real Estate Agent Pack *(coming soon)*
**For:** Realtors, property agents, brokers
**Price:** $49 one-time or included in Studio subscription

Property listing generation, client communication templates, market analysis workflows, and follow-up automation. Knows MLS language, handles buyer and seller pipelines separately.

---

### 🎨 Freelance Designer Pack *(coming soon)*
**For:** Solo designers, creative freelancers
**Price:** $49 one-time or included in Studio subscription

Client onboarding, proposal generation, feedback management, portfolio copy, and project scope protection. Knows design workflows and common freelancer pain points.

---

### 🎙️ Podcast Creator Pack *(coming soon)*
**For:** Independent podcasters
**Price:** $49 one-time or included in Studio subscription

Episode planning, guest research, show notes generation, social clips from transcripts, and newsletter content. Handles the production-to-promotion pipeline.

---

### 🛒 E-commerce Operator Pack *(coming soon)*
**For:** Shopify and ecommerce store owners
**Price:** $49 one-time or included in Studio subscription

Product descriptions, email sequences, ad copy, customer service templates, and inventory planning. Knows ecommerce workflows and marketing cycles.

---

## Pricing Options

| Option | Price | What You Get |
|--------|-------|--------------|
| **Individual Pack** | $49 one-time | Any single pack, yours forever |
| **Studio All-Access** | $19/month | Every current pack + every future pack + monthly updates |
| **Studio Annual** | $149/year | Same as monthly, saves $79 |

---

## Which Should You Pick?

**Buy an individual pack if:**
- You know exactly which pack you need
- You prefer one-time purchases
- You won't use more than one pack

**Subscribe to Studio if:**
- You're interested in 2+ packs
- You want every future pack we build (new ones shipping monthly)
- You want updates and priority support

**Start with Ground Zero if:**
- You're still figuring out which pack fits
- You want to learn the system first
- You're not sure this whole "AI agent" thing is for you

---

## How to Get a Paid Pack

Visit **[zaheer.studio/studio](https://zaheer.studio/studio)** and browse the catalog.

When you buy, you'll get:
1. Immediate download of the pack files
2. Setup instructions to drop them into Claude Code
3. A 15-20 minute domain-specific onboarding that customizes it to you
4. Access to the full skill set from day one

---

## Questions?

**"Can I keep using the free pack after buying a paid pack?"**
Yes. The paid packs go in different folders. Run whichever one you need.

**"What if I cancel the Studio subscription?"**
You keep all the files you've downloaded. You just don't get new monthly updates or new packs that ship after you cancel.

**"Are the packs hard to use?"**
No. Each one has an onboarding flow that sets it up for you in 10-20 minutes. You don't need to be technical.

**"Can I try a paid pack before buying?"**
Ground Zero IS the try. It's the same system structure, just domain-generic. If you like how this works, the paid packs work the same way but with way more built in.

---

## Ready?

Head to **[zaheer.studio/studio](https://zaheer.studio/studio)** and grab the pack that fits your work.

Or keep using this free pack for a while. Either way, you're running the Zaheer system. Welcome.
