# SKILLS.md — Ship Stack

Skills are reusable processes your agent can follow by name. Once a skill exists, you never explain that process again.

---

## How Skills Work

A skill is a markdown file that captures a complete process step by step. Your agent reads the skill file and follows it exactly every time.

**Example:** Instead of explaining how to set up Stripe every time you build an app, you have a `stripe-setup.md` skill. Say "use the stripe setup skill" and your agent follows the same process perfectly every time.

---

## Creating a Skill

**After completing any process with your agent**, say:
> "Create a skill for what we just did"

Your agent packages up that process into a skill file and saves it to your `core/skills/` folder automatically.

**Or describe a process and ask your agent to build the skill:**
> "Create a skill for deploying a new app to Vercel"

---

## Using a Skill

> "Use my [skill name] skill to [task]"

Example:
> "Use my stripe setup skill to add payments to my cover letter app"

---

## Skill Ideas to Create as You Go

Every time you complete a process, consider turning it into a skill. Good candidates:

| Process | Skill Name |
|---------|-----------|
| Deploy a new app to Vercel | `vercel-deploy` |
| Add Stripe Payment Link to an app | `stripe-payment-link` |
| Set up a new GitHub repo | `github-repo-setup` |
| Add Supabase auth to an app | `supabase-auth` |
| Set up a custom domain on Vercel | `domain-setup` |
| Build and deploy a full app end to end | `new-app-builder` |

---

## Included Skills (Updated Monthly)

New skills are included with each monthly Ship Stack update. Drop the new files from the update's `skills/` folder into your `core/skills/` folder.

| Skill | Description | Added |
|-------|-------------|-------|
| More coming in updates | | |

---

## Global vs App-Specific Skills

**Global skills** — useful in every project (save to `core/skills/`):
- Deployment processes
- Payment setup
- Domain configuration

**App-specific skills** — only relevant to one app (note in the skill file which app it's for):
- Specific API integrations
- App-specific workflows
- Custom processes for a particular tool
