# Ship Stack — AI App Builder Agent
### Build and ship web apps with AI. From idea to live URL in 48 hours.

---

## What You Have

This is your AI App Builder Agent — a system that gives Claude Code a complete brain for building web apps. Once set up, your agent knows your tools, your stack, your preferences, and exactly how to build and deploy apps.

Building a new app is as simple as:
> *"I want to build a cover letter generator"*

Your agent handles the rest.

---

## Folder Structure

```
ship-stack/
│
├── core/                 ← YOUR personal files — never overwrite these
│   ├── CLAUDE.md         ← Your agent's brain — loads every session
│   ├── MEMORY.md         ← Saves what your agent learns about you
│   ├── ACCOUNTS.md       ← Your tools and account statuses
│   ├── APPS.md           ← Every app you build, tracked here
│   └── skills/           ← Your custom skill files live here
│
└── updates/              ← Safe to replace with monthly updates
    ├── README.md         ← This file
    ├── ONBOARDING.md     ← First-time setup
    ├── APP_BUILD_PROCESS.md  ← How every app gets built
    ├── STACK.md          ← Tech options and recommendations
    ├── BUSINESS_RULES.md ← Rules that keep you fast and focused
    └── SKILLS.md         ← How the skills system works
```

**Important:** The `core/` folder is yours. Your agent fills it in with your details during onboarding and updates it as you work. Never overwrite it with an update file.

---

## Before You Start

Make sure you've completed the prerequisites listed on the download page. You'll need:

- Claude Code installed and authenticated with a Claude Pro account
- The ability to run Claude Code in this folder (instructions on download page)

Your agent will walk you through setting up any accounts you haven't created yet.

---

## Getting Started — First Time

Open Claude Code pointed at this folder and type:

```
start
```

Your agent will detect that you're new and launch onboarding automatically. It will ask you everything it needs to know, set up your files, and get you ready to build.

**You only do this once.** After that, your agent remembers everything.

---

## After Onboarding

**Build an app:**
> "I want to build [your idea]"

**Validate an idea first:**
> "Help me validate my idea for [idea]"

**Check your apps:**
> "Show me my app status"

**Create a skill:**
> "Create a skill for what we just did"

**Update your stack:**
> "Switch my [layer] from [X] to [Y]"

---

## Monthly Updates

As a subscriber you get updated files each month — new skills, stack improvements, new app templates, and fixes. When an update arrives:

1. Replace everything in your `updates/` folder with the new files
2. Add any new skill files from the update into your `core/skills/` folder
3. **Do not touch your `core/` folder** — your personal data stays safe

Your agent automatically picks up the improvements next session.

---

## Support

- Questions: [your support email]
- Community: [your Discord or community link]
- Changelog: [your changelog URL]

---

*Powered by Claude Code from Anthropic. Claude Pro subscription required separately.*
