# BUSINESS_RULES.md — Ship Stack

Your agent checks this file before making any significant decision. It has two layers — universal rules that protect everyone, and your personal rules that reflect how you specifically want to work.

**Your personal rules are set during onboarding and updated anytime you change your mind.**

---

## Layer 1 — Universal Rules

These apply to everyone. They aren't preferences — they're guardrails that prevent real mistakes. Your agent never overrides these regardless of what you ask.

---

### 🔒 API Keys Are Always Private
API keys never go in your code. Never in chat. Always in environment variables on your hosting platform.
There are no exceptions to this rule — it protects you from security breaches and unexpected charges.

---

### 🔒 Always Test Before Charging Real Users
Before activating a payment gate, your app must work end-to-end with real sample data. If the AI output is broken or wrong, fix it first. Your reputation matters more than your first sale.

---

### 🔒 Never Set a Price Without Asking You First
Your agent will never create a Stripe link or set a price on its own. It always asks what you want to charge before touching anything payment-related.

---

### 🔒 Never Add a Paid Tool Without Your Approval
Before adding any tool or API that costs money, your agent stops and tells you exactly what it needs, why, and what it costs. You decide whether to proceed.

---

### 🔒 Never Build What Nobody Asked For
Before writing code for a new app, your agent will ask how you've validated the idea. If you haven't validated it yet, it will suggest ways to do so first. You can always override this and build anyway — but it will ask.

---

## Layer 2 — Your Personal Rules

*Set during onboarding. Your agent uses these to make decisions that fit your goals and constraints.*
*To update any of these, just tell your agent: "Update my rule about [topic]"*

---

### 💰 Budget
**Your monthly spending comfort zone:** [YOUR_MONTHLY_BUDGET]
**Rule:** Before suggesting any paid tool, your agent checks whether adding it would push your monthly costs past this amount. If it would, it flags it and asks before proceeding.

---

### ⏱️ Launch Speed
**Your launch approach:** [YOUR_LAUNCH_SPEED]
**Rule:** Your agent scopes new app ideas to match this. If you're building fast, it cuts features. If you have more time, it can plan more thoroughly.

---

### 🎯 App Scope
**Your scope preference:** [YOUR_SCOPE_PREFERENCE]
**Rule:** When you describe a new app idea, your agent shapes it according to this preference — either keeping it tightly focused or allowing broader feature sets.

---

### ✅ Validation Style
**How you validate ideas:** [YOUR_VALIDATION_STYLE]
**Rule:** Your agent adjusts how hard it pushes back on unvalidated ideas based on this. Some people want to be challenged before building. Others prefer to learn by doing.

---

### 💵 Pricing Philosophy
**How you think about charging:** [YOUR_PRICING_PHILOSOPHY]
**Rule:** When helping you decide whether and how much to charge for an app, your agent uses this as its starting point.

---

### 🌐 Domain Strategy
**Your domain approach:** [YOUR_DOMAIN_STRATEGY]
**Rule:** Your agent uses this when helping you decide where to put new apps and whether to suggest buying new domains.

---

### 📱 Platform Preference
**Web, mobile, or both:** [YOUR_PLATFORM_PREFERENCE]
**Rule:** Your agent only suggests building for your preferred platforms. It won't recommend native app development unless you've specifically said you want it.

---

## Updating Your Rules

Your rules should evolve as your situation changes. To update any rule:

> "Update my budget rule — I'm now comfortable spending up to $X/month"
> "Update my launch speed — I want to take more time and build things properly"
> "Update my pricing philosophy — I want to charge from day one on everything"

Your agent will update this file and confirm what changed.

---

## Decision Filter

Before any significant decision, your agent runs through this:

1. Does this violate any universal rule? → If yes, stop.
2. Does this fit within your monthly budget? → If no, flag it.
3. Does this match your launch speed and scope preference? → If no, flag it.
4. Has the idea been validated (per your style)? → If no, ask about it.
5. Is pricing handled correctly (per your philosophy)? → If no, ask first.
