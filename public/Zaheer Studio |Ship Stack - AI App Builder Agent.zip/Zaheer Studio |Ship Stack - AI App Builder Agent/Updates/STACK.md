# STACK.md — Ship Stack

This file defines the tech stack for your apps. Your agent uses whatever is set in `CLAUDE.md` by default — but you can always change things here or ask your agent to use something different for a specific app.

---

## How Your Stack Works

Every app needs five things:

| Layer | What It Does |
|---|---|
| **Frontend** | What users see and interact with — buttons, forms, layouts |
| **Backend** | The logic that happens behind the scenes — AI calls, data processing |
| **AI** | The intelligence that powers your app's features |
| **Payments** | How you collect money from users |
| **Hosting** | Where your app lives on the internet |

---

## Recommended Defaults

These are the best starting options for most people. They're free or very cheap, require no server management, and work well together.

### Frontend — React + Tailwind CSS + Vite
**What it is:** React is the most popular way to build web apps. Tailwind makes styling fast. Vite makes it all run quickly.
**Why we recommend it:** Huge community, tons of examples online, works with all the best prototyping tools.
**Alternatives:** Vue.js (similar, slightly simpler), plain HTML/CSS (simpler but harder to scale)

### Backend — Vercel Serverless Functions
**What it is:** Little pieces of code that run in the cloud when a user takes an action. No server to manage.
**Why we recommend it:** Free, auto-scales, deploys with your frontend automatically.
**Alternatives:** Netlify Functions (same concept, different platform), Supabase Edge Functions (good if you're already using Supabase)

### AI — Two Options (Your Agent Picks the Right One Per App)

**Option A: Anthropic Claude API** — for apps that transform or generate text
- Examples: resume rewriter, cover letter generator, email writer
- Cost: ~$0.01–0.05 per user request
- Quality: Excellent
- Models available: `claude-haiku-4-5-20251001` (fast/cheap), `claude-sonnet-4-6` (best quality)
- Sign up: console.anthropic.com

**Option B: Groq + Tavily** — for apps that need live internet data
- Examples: news summarizer, market tracker, competitor research tool
- Cost: Free (both have generous free tiers)
- Groq: fast AI analysis — console.groq.com
- Tavily: web search API — app.tavily.com
- Your agent uses this automatically for research apps — no approval needed

**Alternatives:**
- OpenAI GPT-4 — similar to Anthropic, personal preference
- Google Gemini — good free tier (note: can have quota issues depending on account setup)
- Local models via Ollama — free but requires more setup, best for Mac Mini or dedicated machine

### Payments — Stripe Payment Links
**What it is:** You create a payment link in Stripe's dashboard and put it in your app. No code needed.
**Why we recommend it:** Fastest way to start charging. Works in 5 minutes.
**When to upgrade:** When you need subscription billing or want a custom checkout UI — use Stripe Checkout or Stripe Billing
**Alternatives:** Lemon Squeezy (simpler for digital products), Gumroad (even simpler, higher fees)

### Hosting — Vercel
**What it is:** Puts your app on the internet. Automatically deploys every time you push code to GitHub.
**Why we recommend it:** Free, fast, no configuration needed.
**Alternatives:** Netlify (very similar), Cloudflare Pages (faster globally, slightly more setup)

---

## Add These When You Need Them

Don't add these upfront — only when an app specifically requires it.

| Tool | What It's For | Cost | When to Add |
|---|---|---|---|
| **Supabase** | Database + user login | Free tier | When app needs accounts or stored data |
| **Resend** | Sending emails to users | Free up to 3k/month | When app sends notifications or digests |
| **Upstash** | Rate limiting, caching | Free tier | When you need to limit API abuse |
| **Make.com** | Automating workflows | Free tier | When you want tasks to run automatically |
| **Cloudinary** | Image storage and processing | Free tier | When app handles user-uploaded images |

---

## Prototyping Tools

These speed up the initial frontend build dramatically.

| Tool | What It Does | Best For |
|---|---|---|
| **Bolt.new** | Describe your app, it builds the full frontend | Most apps — recommended starting point |
| **v0.dev** | Generates React components from descriptions | When you need specific UI components |
| **Lovable** | Similar to Bolt, slightly different workflow | Personal preference |

Your agent writes the prompt for whichever tool you use — you just paste it in and review the output.

---

## Changing Your Stack

To change a default for all future apps:
> "Update my stack — I want to use [X] instead of [Y]"

Your agent updates `CLAUDE.md` and `STACK.md`.

To use something different for just one app:
> "For this app, use [X] instead of [Y]"

Your agent uses it for that app only and notes it in `APPS.md`.

---

## Your Current Stack

Set during onboarding. Update anytime.

| Layer | Your Choice |
|---|---|
| Frontend | [YOUR_FRONTEND] |
| Backend | [YOUR_BACKEND] |
| AI | [YOUR_AI_CHOICE] |
| Payments | [YOUR_PAYMENT_TOOL] |
| Hosting | [YOUR_HOSTING] |
| Prototyping | [YOUR_PROTOTYPING_TOOL] |
