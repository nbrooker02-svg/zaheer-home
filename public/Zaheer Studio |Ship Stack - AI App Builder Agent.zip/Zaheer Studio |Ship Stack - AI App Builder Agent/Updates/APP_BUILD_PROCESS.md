# APP BUILD PROCESS — Ship Stack

Read this file whenever you want to build a new app. Your agent follows every phase in order.

---

## Before You Build — Validate First

Before writing a single line of code, your agent will help you answer:
- Who specifically is this for?
- What pain does it solve?
- Would someone pay for it? How much?
- Can it be built in 48 hours?

If you can't answer all four, validate first. Post in a relevant online community, ask potential users, or run a quick poll. Don't build something nobody asked for.

---

## Choosing Your AI Stack

| App Type | Stack | Cost |
|---|---|---|
| Text transformation (rewrite, summarize, generate copy) | Anthropic Claude API | Paid — ~$0.01–0.05/request |
| Live data, research, news, market info | Tavily (search) + Groq (analysis) | Free |
| Simple chatbot or Q&A | Groq alone | Free |

**Rule:** Your agent will always confirm before adding any paid API. Free options get used automatically.

---

## Standard Folder Structure

Every app follows this exact structure:

```
[app-name]/
├── src/
│   ├── App.jsx           — main app component
│   ├── main.jsx          — entry point
│   └── index.css         — Tailwind imports
├── api/
│   └── [endpoint].js     — Vercel serverless function
├── vercel.json           — subpath routing (REQUIRED for every app)
├── vite.config.js        — base path config (REQUIRED for every app)
├── package.json
└── index.html
```

---

## Critical Config Files

**Every app needs both of these or it will break.** Your agent adds them automatically.

### vercel.json
```json
{
  "rewrites": [
    { "source": "/[appname]/assets/(.*)", "destination": "/assets/$1" },
    { "source": "/[appname]", "destination": "/index.html" },
    { "source": "/[appname]/(.*)", "destination": "/index.html" }
  ]
}
```

### vite.config.js
```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/[appname]'
})
```

Replace `[appname]` with your actual app path in both files (e.g. `resume-rewriter`, `cover-letter`).

---

## API Templates

### Template A — Anthropic Claude (paid, text apps)

```javascript
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { inputField } = req.body;
  if (!inputField) return res.status(400).json({ error: 'Missing input' });

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 2000,
      messages: [{ role: 'user', content: `Your prompt using: ${inputField}` }]
    })
  });

  const data = await response.json();
  res.status(200).json({ result: data.content[0].text });
}
```

**Required env var:** `ANTHROPIC_API_KEY`
**Where to get it:** console.anthropic.com → API Keys
**How to add it:** `vercel env add ANTHROPIC_API_KEY production --cwd ~/Documents/[app-name]`

---

### Template B — Tavily + Groq (free, research/live data apps)

Use when your app needs current information from the web.

```javascript
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { topic } = req.body;
  if (!topic) return res.status(400).json({ error: 'Missing topic' });

  try {
    // Step 1: Search the web
    const searchRes = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: process.env.TAVILY_API_KEY,
        query: topic,
        search_depth: 'basic',
        max_results: 5,
      }),
    });
    const searchData = await searchRes.json();
    const context = (searchData.results ?? [])
      .map(r => `${r.title}\n${r.content}`)
      .join('\n\n---\n\n');

    // Step 2: Analyze with Groq
    const groqRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        temperature: 0.2,
        messages: [{
          role: 'user',
          content: `Using this web data:\n\n${context}\n\nNow: [your instruction about ${topic}]`
        }],
      }),
    });
    const groqData = await groqRes.json();
    const text = groqData.choices?.[0]?.message?.content;
    if (!text) return res.status(500).json({ error: 'No response. Try again.' });

    res.status(200).json({ result: text });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed. Please try again.' });
  }
}
```

**Required env vars:**
- `TAVILY_API_KEY` — free at app.tavily.com (sign in with GitHub)
- `GROQ_API_KEY` — free at console.groq.com

---

## Build Phases

### Phase 1 — Scaffold the Frontend with Bolt.new

**What Bolt.new is:** An AI tool that builds a complete React frontend from a text description. Go to bolt.new.

Your agent writes the Bolt.new prompt for you. A good prompt includes:
- What the app does in one sentence
- Who it's for
- The full user journey step by step
- Stack: React + Tailwind CSS + Vite
- UI layout description
- Placeholder buttons wired to `/api/[endpoint]` — no AI logic in Bolt
- Mobile-responsive, clean and minimal
- No auth, no database (unless scoped for it)

**Steps:**
1. Your agent gives you the Bolt prompt
2. Go to bolt.new and paste it
3. Review the output in Bolt's editor — check that it looks right
4. In Bolt: click the GitHub icon → name the repo → Create repository
5. Tell your agent "Bolt is done, repo is [repo-name]"

### Phase 2 — Add the Backend

Your agent clones the repo and adds:
- `api/[endpoint].js` — the serverless function
- `vercel.json` — routing config
- `vite.config.js` — base path

Then commits and pushes to GitHub.

### Phase 3 — Deploy to Vercel

```bash
cd ~/Documents/[app-name]
vercel --prod
```

When prompted: create new project → accept defaults.

**Adding API keys (you do this, not the agent):**
```bash
vercel env add ANTHROPIC_API_KEY production --cwd ~/Documents/[app-name]
# or for free stack:
vercel env add TAVILY_API_KEY production --cwd ~/Documents/[app-name]
vercel env add GROQ_API_KEY production --cwd ~/Documents/[app-name]
```

Then redeploy:
```bash
vercel --prod --cwd ~/Documents/[app-name]
```

### Phase 4 — Assign to Your Domain

```bash
vercel domains add [YOUR_DOMAIN]/[appname]
```

If you have a home page project, add a proxy rewrite so traffic routes correctly.

### Phase 5 — Test Before Charging

1. Open your live URL
2. Test with real sample data
3. Confirm the AI output is working
4. Only add Stripe after confirming it works end to end

### Phase 6 — Add Payment Gate

1. Tell your agent what price to charge — it will never assume
2. Create a Stripe Payment Link in your Stripe dashboard
3. Your agent wires the link to your CTA button
4. Commit and push

---

## Common Issues and Exact Fixes

### 404 on API call
**Cause:** `/api/[endpoint].js` missing or wrong filename
**Fix:** File must be at exactly `api/[endpoint].js` — no leading slash. Commit and push.

### Blank page at /appname
**Cause:** Wrong `base` in `vite.config.js` or missing asset rewrites in `vercel.json`
**Fix:** Vite base must exactly match your appname. The asset rewrite in vercel.json must come first.

### Vercel won't auto-deploy after push
**Cause:** Git commit email doesn't match your GitHub account email
**Fix:**
```bash
git config --global user.email "your-github-email@example.com"
```
Then make a new commit and push.

### API key not working in production
**Cause:** Key not set in Vercel env vars, or set for wrong environment
**Fix:**
```bash
vercel env rm ANTHROPIC_API_KEY production --cwd ~/Documents/[app-name]
vercel env add ANTHROPIC_API_KEY production --cwd ~/Documents/[app-name]
vercel --prod --cwd ~/Documents/[app-name]
```

### Vercel function timing out
**Cause:** External API calls taking too long (10 second limit on free Vercel plan)
**Fix:** Run API calls in parallel with `Promise.all`, reduce `max_results` in Tavily, shorten prompts

### Domain shows "Invalid Configuration"
**Cause:** DNS records not set up correctly at your domain registrar
**Fix:** Go to your domain registrar's DNS settings. Delete any conflicting A records or URL redirects. Add only what Vercel specifies in its domain setup instructions.

---

## Launch Checklist

### Build
- [ ] Idea validated — someone will pay for this
- [ ] Bolt prompt written and reviewed
- [ ] Repo created on GitHub
- [ ] `api/[endpoint].js` added
- [ ] `vercel.json` added with correct appname
- [ ] `vite.config.js` updated with correct base path

### Deploy
- [ ] `vercel --prod` run from project folder
- [ ] API key(s) added via `vercel env add`
- [ ] Redeployed after adding env vars
- [ ] Live URL tested end to end with real data

### Revenue
- [ ] Stripe Payment Link created at correct price
- [ ] Payment Link URL wired to CTA button
- [ ] Payment flow tested (Stripe test mode first)
- [ ] App entry added to CLAUDE.md

### App is DONE when:
- `[YOUR_DOMAIN]/[appname]` loads correctly
- AI calls work end to end
- Stripe payment tested and confirmed working
