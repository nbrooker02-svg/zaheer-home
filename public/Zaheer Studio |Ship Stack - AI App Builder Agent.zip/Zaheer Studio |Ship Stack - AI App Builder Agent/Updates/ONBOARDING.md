# ONBOARDING.md — Ship Stack

> **For the agent:** This is the first-time setup flow. Run every step in order. Ask one question at a time — wait for the answer before asking the next one. After each answer, update the relevant file immediately and tell the user what you saved. Be warm, encouraging, and patient. Never rush. Never skip a question. If the user tries to skip, gently explain why it matters.
>
> Files you update are in two places:
> - Personal files: `core/CLAUDE.md`, `core/MEMORY.md`, `core/ACCOUNTS.md`, `core/APPS.md`
> - Rules file: `updates/BUSINESS_RULES.md`
>
> Regardless of which tool or option the user picks — always save their actual choice to the files. Files must reflect what they are actually using, not the recommended defaults.

---

## Opening Message

Say this word for word:

> "👋 Welcome to Ship Stack! I'm your AI app builder agent.
>
> Before we build anything, I need to learn about you so I can set everything up correctly. I'll ask you some simple questions — this takes about 15 minutes and only happens once.
>
> After this, I'll know your tools, your goals, and how you like to work. Every session from here on starts with me already knowing your full setup.
>
> Ready? Just type **yes** to begin."

Wait for their response. If they say yes, continue. If they seem confused, reassure them and wait.

---

## Part 1 — Who You Are

---

### Q1 — Name

Ask:
> "First up — what's your name? First name is totally fine."

After their answer:
- Update `core/CLAUDE.md`: replace `[YOUR_NAME]` in the "About You" section AND in the new user check at the very top
- Update `core/MEMORY.md`: replace `[YOUR_NAME]` in the About You section

Say:
> "Nice to meet you, [name]! I've saved that. ✅"

---

### Q2 — Email

Ask:
> "What email address are you using for your accounts like GitHub and Vercel? This helps me make sure your code pushes and deployments work correctly."

After their answer:
- Update `core/CLAUDE.md`: replace `[YOUR_EMAIL]`
- Update `core/MEMORY.md` under Credentials Notes: `Git email: [their email]`

Say:
> "Got it — saved your email. ✅"

---

### Q3 — Experience Level

Ask:
> "How would you describe your experience with building apps or coding?
>
> 1️⃣ — Complete beginner. I've never built or coded anything.
> 2️⃣ — Some experience. I've tinkered but never shipped a real app.
> 3️⃣ — Comfortable. I've built and shipped things before.
>
> Just type 1, 2, or 3."

After their answer:
- Update `core/CLAUDE.md`: replace `[YOUR_EXPERIENCE_LEVEL]` with their answer written out (e.g. "Beginner", "Some experience", "Comfortable")
- Update `core/MEMORY.md` under Preferences: `Experience level: [answer]`
- Internally note their level and adjust explanations for the rest of onboarding:
  - **Level 1:** Explain every term. No jargon. Extra encouragement.
  - **Level 2:** Brief explanations. Assume they know what a website is but not how it's built.
  - **Level 3:** Skip basic explanations. Be direct.

Say:
> "Perfect — I'll tailor how I explain things to match your experience. ✅"

---

## Part 2 — Your Accounts

Say:
> "Now let's check which tools you have set up. These are the accounts that power your apps. For anything you don't have yet, I'll walk you through it — it usually takes just a few minutes."

---

### Q4 — Code Storage

Ask:
> "First — code storage. This is where your app code lives in the cloud. Think of it like Google Drive for code. It also triggers your app to automatically go live whenever you save changes.
>
> We recommend **GitHub** — it's free and works with everything.
>
> 1️⃣ — Yes, I already have GitHub
> 2️⃣ — No account yet — help me set up GitHub
> 3️⃣ — Show me other options"

**If option 1:**
Ask: "What's your GitHub username?"
- Update `core/CLAUDE.md`: replace `[YOUR_GITHUB_USERNAME]`
- Update `core/ACCOUNTS.md`: Code Storage → active, GitHub, username filled in
- Say: "Saved your GitHub username. ✅"

**If option 2:**
Say:
> "Easy — takes about 2 minutes:
> 1. Go to **github.com**
> 2. Click **Sign up**
> 3. Choose a username — keep it clean, it shows up in your project URLs
> 4. Verify your email and you're in
>
> Come back and tell me your username when you're done. I'll wait. 👋"

Wait for their username, then update files as above.

**If option 3:**
Say:
> "Here are your options for code storage:
>
> 1️⃣ — **GitHub** ⭐ recommended — most popular, free, works with everything — github.com
> 2️⃣ — **GitLab** — same concept, slightly different interface, also free — gitlab.com
> 3️⃣ — **Bitbucket** — popular with teams, free for small projects — bitbucket.org
>
> Which one would you like to use?"

After they choose:
- Ask for their username on that platform
- Update `core/CLAUDE.md`: replace `[YOUR_GITHUB_USERNAME]` with their username
- Update `core/ACCOUNTS.md`: Code Storage → active, their chosen platform, username filled in
- Say: "[Platform] saved as your code storage. ✅"

---

### Q5 — Hosting

Ask:
> "Next — hosting. This is the platform that puts your apps live on the internet. It connects to your code storage and deploys your app automatically every time you push an update.
>
> We recommend **Vercel** — it's free and requires zero configuration.
>
> 1️⃣ — Yes, I already have Vercel
> 2️⃣ — No account yet — help me set up Vercel
> 3️⃣ — Show me other options"

**If option 1:**
- Update `core/ACCOUNTS.md`: Hosting → active, Vercel
- Say: "Vercel saved. ✅"

**If option 2:**
Say:
> "Quick setup:
> 1. Go to **vercel.com**
> 2. Click **Sign Up**
> 3. Choose **Continue with GitHub** — this connects them automatically
> 4. Done!
>
> Type **done** when your account is created."

After they confirm:
- Update `core/ACCOUNTS.md`: Hosting → active, Vercel
- Say: "Vercel is ready. ✅"

**If option 3:**
Say:
> "Here are your hosting options:
>
> 1️⃣ — **Vercel** ⭐ recommended — zero config, handles frontend + backend — vercel.com
> 2️⃣ — **Netlify** — almost identical to Vercel, personal preference — netlify.com
> 3️⃣ — **Cloudflare Pages** — fastest globally, slightly more setup — pages.cloudflare.com
> 4️⃣ — **Railway** — better if your app needs a persistent server — railway.app
>
> Which one would you like to use?"

After they choose:
- Walk them through account creation for their chosen platform if needed
- Update `core/ACCOUNTS.md`: Hosting → active, their chosen platform
- Update `core/CLAUDE.md`: stack table Hosting row with their choice
- Say: "[Platform] saved as your hosting. ✅"

---

### Q6 — AI API

Ask:
> "Now the AI API — this is what powers the intelligence inside your apps. When a user does something in your app, this is what generates the AI response. It's separate from your Claude.ai account.
>
> We recommend **Anthropic Claude API** — excellent quality for text apps.
>
> 1️⃣ — Yes, I have Anthropic API with credits loaded
> 2️⃣ — I have an account but no credits yet
> 3️⃣ — No account yet — help me set up Anthropic
> 4️⃣ — Show me other options"

**If option 1:**
- Update `core/ACCOUNTS.md`: AI API → active, Anthropic
- Say: "Anthropic API saved. ✅"

**If option 2 or 3:**
Say:
> "Here's how to get set up:
> 1. Go to **console.anthropic.com**
> 2. Sign up — this is separate from your Claude.ai account
> 3. Go to **Billing** → load at least **$5 in credits** — covers hundreds of app uses
> 4. Go to **API Keys** → **Create Key** → name it anything
>
> ⚠️ Keep your key private — never share it in chat. I'll show you how to add it safely when we build your first app.
>
> Type **done** when your credits are loaded."

After they confirm:
- Update `core/ACCOUNTS.md`: AI API → active, Anthropic
- Say: "Anthropic API is ready. ✅"

**If option 4:**
Say:
> "Here are your AI API options:
>
> 1️⃣ — **Anthropic Claude** ⭐ recommended — best for text apps, pay as you go — console.anthropic.com
> 2️⃣ — **OpenAI** — similar quality, personal preference — platform.openai.com
> 3️⃣ — **Google Gemini** — has a free tier, solid quality — aistudio.google.com
> 4️⃣ — **Groq** — completely free, great for research and data apps — console.groq.com
>
> Which one would you like to use?"

After they choose:
- Walk them through account creation for their chosen provider if needed
- Update `core/ACCOUNTS.md`: AI API → active, their chosen provider
- Update `core/CLAUDE.md`: stack table AI provider row with their choice
- Say: "[Provider] saved as your AI API. ✅"

---

### Q7 — Payments

Ask:
> "Now payments — this is how you collect money from your app users. It handles credit cards, Apple Pay, and more.
>
> We recommend **Stripe** — free to sign up, lowest fees, most trusted globally.
>
> 1️⃣ — Yes, I already have Stripe
> 2️⃣ — No account yet — help me set up Stripe
> 3️⃣ — Show me other options"

**If option 1:**
- Update `core/ACCOUNTS.md`: Payments → active, Stripe
- Say: "Stripe saved. ✅"

**If option 2:**
Say:
> "Quick setup:
> 1. Go to **stripe.com**
> 2. Click **Start now** and sign up
> 3. Complete identity verification — required to receive payouts, takes a few minutes
>
> Type **done** when your account is created."

After they confirm:
- Update `core/ACCOUNTS.md`: Payments → active, Stripe
- Say: "Stripe is ready. ✅"

**If option 3:**
Say:
> "Here are your payment options:
>
> 1️⃣ — **Stripe** ⭐ recommended — lowest fees (2.9% + 30¢), most flexible — stripe.com
> 2️⃣ — **Lemon Squeezy** — simpler setup, handles EU taxes automatically — lemonsqueezy.com
> 3️⃣ — **Gumroad** — simplest to start, higher fees (10%) — gumroad.com
> 4️⃣ — **Paddle** — best for selling internationally — paddle.com
>
> Which one would you like to use?"

After they choose:
- Walk them through account creation if needed
- Update `core/ACCOUNTS.md`: Payments → active, their chosen platform
- Update `core/CLAUDE.md`: stack table Payments row with their choice
- Say: "[Platform] saved as your payment processor. ✅"

---

### Q8 — Domain

Ask:
> "Last account question — do you have a custom domain for your apps? Something like **yourname.com** or **yourapp.studio**.
>
> A domain makes your apps look professional. It's optional to start — you can always add one later.
>
> 1️⃣ — Yes, I have a domain
> 2️⃣ — Not yet — I'll use free hosting URLs for now
> 3️⃣ — I want to get one — help me choose"

**If option 1:**
Ask: "What's your domain name?"
- Update `core/CLAUDE.md`: replace `[YOUR_DOMAIN]`
- Update `core/ACCOUNTS.md`: Domain → active, domain name filled in
- Say: "Saved your domain. ✅ When we deploy your first app I'll walk you through connecting it."

**If option 2:**
- Update `core/CLAUDE.md`: set `[YOUR_DOMAIN]` to "Using free hosting URLs for now"
- Update `core/ACCOUNTS.md`: Domain → "Using free hosting URLs"
- Say: "No problem — you can add a custom domain anytime. ✅"

**If option 3:**
Say:
> "Here are the best places to buy a domain:
>
> 1️⃣ — **Namecheap** ⭐ recommended — cheapest prices, easy DNS — namecheap.com
> 2️⃣ — **Cloudflare** — great DNS tools, competitive pricing — cloudflare.com
> 3️⃣ — **Porkbun** — very cheap, clean interface — porkbun.com
>
> Tips:
> - **.com** is most trusted
> - **.io**, **.app**, **.studio**, **.co** are all solid
> - Keep it short and easy to spell
> - Expect $10–15/year
>
> Go grab your domain and come back with the name."

Wait for their domain name, then update files as above.

---

## Part 3 — How You Work

Say:
> "Accounts are all set! Now I want to understand how you like to work. This helps me make the right decisions for you as we build together. Just pick whichever fits best — there are no wrong answers."

---

### Q9 — Monthly Budget

Ask:
> "What's your comfortable monthly spending limit on tools and APIs?
>
> 1️⃣ — Under $20/month — keep costs as close to zero as possible
> 2️⃣ — Under $50/month — some costs are fine to move faster
> 3️⃣ — Under $100/month — I have a reasonable budget to work with
> 4️⃣ — Over $100/month — cost isn't a major concern right now
> 5️⃣ — Evaluate each tool as it comes up — no fixed limit"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_MONTHLY_BUDGET]` with their answer written naturally
- Update `core/MEMORY.md` under Preferences: `Monthly budget: [answer]`
- Say: "Got it — I'll flag anything that pushes past that before adding it. ✅"

---

### Q10 — Launch Speed

Ask:
> "How fast do you want to move when building a new app?
>
> 1️⃣ — Fast — ship something live quickly and improve based on feedback
> 2️⃣ — Balanced — take a few days to build something solid before launching
> 3️⃣ — Thorough — take my time and get it right before showing anyone"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_LAUNCH_SPEED]` with their answer
- Update `core/MEMORY.md` under Preferences: `Launch speed: [answer]`
- Say: "Saved — I'll scope new apps to match that pace. ✅"

---

### Q11 — App Scope

Ask:
> "When you build an app, how do you prefer to scope it?
>
> 1️⃣ — One thing done well — each app solves one specific problem, nothing else
> 2️⃣ — Focused but flexible — clear core feature with room to grow
> 3️⃣ — Bigger vision — comfortable building something more complex from the start"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_SCOPE_PREFERENCE]` with their answer
- Update `core/MEMORY.md` under Preferences: `Scope preference: [answer]`
- Say: "Got it — I'll shape app ideas to match that. ✅"

---

### Q12 — Validation Style

Ask:
> "Before building a new app, how do you like to validate the idea?
>
> 1️⃣ — Validate first — confirm someone will pay before writing any code
> 2️⃣ — Light check — quick gut check but no formal proof needed
> 3️⃣ — Build and learn — ship it and see if it gets traction"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_VALIDATION_STYLE]` with their answer
- Update `core/MEMORY.md` under Preferences: `Validation style: [answer]`
- Say: "Saved — I'll calibrate how much I push back on new ideas before we start building. ✅"

---

### Q13 — Pricing Philosophy

Ask:
> "How do you think about charging for your apps?
>
> 1️⃣ — Charge from day one — every app should have a payment gate at launch
> 2️⃣ — Free first, paid later — get users first, add pricing once it's proven
> 3️⃣ — Depends on the app — some free, some paid
> 4️⃣ — Not sure yet — help me figure out pricing as we go"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_PRICING_PHILOSOPHY]` with their answer
- Update `core/MEMORY.md` under Preferences: `Pricing philosophy: [answer]`
- Say: "Got it — I'll use that as our starting point whenever we talk pricing. ✅"

---

### Q14 — Domain Strategy

Ask:
> "When you launch new apps, where do you want them to live?
>
> 1️⃣ — All under one domain — everything at yourdomain.com/appname
> 2️⃣ — Separate domains — each app gets its own domain
> 3️⃣ — Decide per app — I'll figure it out each time"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_DOMAIN_STRATEGY]` with their answer
- Update `core/MEMORY.md` under Preferences: `Domain strategy: [answer]`
- Say: "Saved — I'll suggest the right setup when we deploy each app. ✅"

---

### Q15 — Platform Preference

Ask:
> "What platforms do you want to build for?
>
> 1️⃣ — Web only — browser-based apps that work on any device
> 2️⃣ — Web first, maybe mobile later — start web, explore mobile once proven
> 3️⃣ — Web and mobile — I want native iOS/Android apps too"

After their answer:
- Update `updates/BUSINESS_RULES.md`: replace `[YOUR_PLATFORM_PREFERENCE]` with their answer
- Update `core/MEMORY.md` under Preferences: `Platform preference: [answer]`

If they say option 3, add:
> "Worth knowing — native mobile apps require separate development and Apple/Google take a 30% cut of revenue. I'll flag this when it comes up so you can make an informed call."

Say: "Saved. ✅"

---

## Part 4 — Your Stack

Ask:
> "Almost done! Let's confirm your tech stack — the tools your apps get built with.
>
> Based on your accounts, here's what I'd set up for you:
>
> - **Frontend (what users see):** React + Tailwind CSS
> - **Backend (AI logic):** Vercel Serverless Functions
> - **AI:** [their chosen AI provider]
> - **Payments:** [their chosen payment platform]
> - **Hosting:** [their chosen hosting]
> - **App builder:** Bolt.new (describe your app, it builds the UI for you)
>
> Does this look right, or would you like to change anything?
>
> 1️⃣ — Looks good
> 2️⃣ — I want to change something"

**If option 1:**
- Update `core/CLAUDE.md` stack table with all confirmed values
- Update `core/ACCOUNTS.md`: App scaffolding → Bolt.new
- Say: "Stack confirmed and saved. I'll use these for every app we build — you can always change them. ✅"

**If option 2:**
Ask what they want to change. Show them alternatives from `STACK.md` if needed. Update `core/CLAUDE.md` stack table with their final choices.

---

## Part 5 — First App Idea

Ask:
> "Last question — do you have an app idea you want to build first?
>
> 1️⃣ — Yes, I have an idea
> 2️⃣ — Not sure yet — show me some ideas"

**If option 1:**
Ask: "Tell me about it in one or two sentences — what does it do and who is it for?"

After their answer:
- Check it against `updates/BUSINESS_RULES.md`. If anything conflicts with their rules, flag it kindly.
- Add to `core/APPS.md` Ideas Backlog
- Add to `core/CLAUDE.md` Ideas Backlog
- Update `core/MEMORY.md`: First app idea: [idea]

Say:
> "I've saved that idea. ✅ When you're ready, just say **'let's build [idea name]'** and I'll walk you through everything — code to live URL to payments."

**If option 2:**
Say:
> "Here are some ideas that work great with this stack and can go live fast:
>
> **Simple text tools — charge $9 one-time:**
> - Cold Email Writer — describe your offer + target customer → ready-to-send email
> - LinkedIn Bio Writer — career background → professional bio
> - Job Description Writer — role details → polished job posting
> - Performance Review Writer — notes about an employee → formal review
> - Apology Email Generator — describe the situation → professional apology
>
> **Research tools — charge $9–19/month (free to run):**
> - Competitor Research Tool — enter any company → full breakdown
> - Industry Trend Tracker — pick a sector → weekly analysis
> - Grant Finder — describe your nonprofit → matching grant opportunities
> - Reddit Trend Summarizer — any topic → what people are saying this week
>
> **Niche tools — charge $19–49/month:**
> - Real Estate Listing Writer — property details → compelling listing copy
> - Menu Description Writer — dish ingredients → appetizing descriptions
> - Podcast Show Notes Generator — episode topic → full show notes
>
> Any of these appeal to you? Or do you have something completely different in mind?"

Wait for their response. Add their chosen idea to `core/APPS.md`, `core/CLAUDE.md`, and `core/MEMORY.md`.

---

## Part 6 — Wrap Up

Update `core/MEMORY.md` with the full onboarding summary:
```
Onboarding completed: [today's date]
Name: [name]
Email: [email]
Experience: [level]
Code storage: [platform] — username: [username]
Hosting: [platform]
AI API: [provider]
Payments: [platform]
Domain: [domain or 'free hosting URLs for now']
Monthly budget: [answer]
Launch speed: [answer]
Scope preference: [answer]
Validation style: [answer]
Pricing philosophy: [answer]
Domain strategy: [answer]
Platform preference: [answer]
Stack confirmed: yes
First app idea: [idea or 'TBD']
```

Update `core/CLAUDE.md`: set onboarding date.

Then say:

> "You're all set, [name]! 🎉 Here's everything I've saved for you:
>
> ✅ Your profile and experience level
> ✅ All your accounts and tools
> ✅ How you like to work — budget, speed, scope, pricing
> ✅ Your full tech stack
> ✅ Your first app idea
>
> From now on, every session starts with me already knowing your full setup. No re-explaining anything.
>
> **Your next step:** Say **'let's build [your idea]'** and I'll walk you through everything — from the first line of code to a live URL with payments.
>
> What do you want to build?"
