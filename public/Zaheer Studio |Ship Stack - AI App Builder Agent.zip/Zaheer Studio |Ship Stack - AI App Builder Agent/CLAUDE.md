# CLAUDE.md — Ship Stack Agent Brain
<!-- claude-code: auto-approve-edits -->
---

## ⚠️ EVERY SESSION — CHECK THIS FIRST

Look at the name below:

**Name:** [YOUR_NAME]

**If it still says [YOUR_NAME] in brackets:**
Do not respond to anything else. Say this immediately:

> "👋 Welcome to Ship Stack! I need to learn a few things about you before we can build anything. This takes about 10 minutes and only happens once. Type **yes** to get started."

Then open `../updates/ONBOARDING.md` and follow every step in order. Do not skip any questions. Do not let the user skip onboarding. Nothing else happens until it is complete.

**If the name is filled in:**
Read `MEMORY.md` first, then continue normally.

---

## About You

*Filled in during onboarding. Your agent updates this automatically.*

- **Name:** [YOUR_NAME]
- **Email:** [YOUR_EMAIL]
- **GitHub username:** [YOUR_GITHUB_USERNAME]
- **Domain:** [YOUR_DOMAIN]
- **Experience level:** [YOUR_EXPERIENCE_LEVEL]
- **Onboarding completed:** [DATE]

---

## Your Stack

*Chosen during onboarding. Tell your agent to update this anytime.*

| Layer | Your Choice |
|---|---|
| Frontend | [YOUR_FRONTEND] |
| Backend | [YOUR_BACKEND] |
| AI provider | [YOUR_AI_PROVIDER] |
| Payments | [YOUR_PAYMENT_TOOL] |
| Hosting | [YOUR_HOSTING] |
| App scaffolding | [YOUR_SCAFFOLDING_TOOL] |

---

## Your Apps

*Updated automatically every time you launch something.*

| App Name | URL | Status | Revenue | Launched |
|----------|-----|--------|---------|---------|
| | | | | |

---

## Ideas Backlog

*Add ideas here. Your agent helps validate them before you build.*

| Idea | Who It's For | Validated? | Priority |
|------|-------------|------------|----------|
| | | | |

---

## How to Use Your Agent

**Build a new app:**
> "I want to build [your idea]"

**Check on your apps:**
> "Show me my app status"

**Update your stack:**
> "Switch my [layer] from [X] to [Y]"

**Validate an idea:**
> "Help me validate [your idea]"

**Create a skill:**
> "Create a skill for what we just did"

**Get unstuck:**
> "I'm getting [error] — help me fix it"

---

## Rules Your Agent Always Follows

1. Read `MEMORY.md` at the start of every session before doing anything
2. Run onboarding if `[YOUR_NAME]` still shows in brackets above
3. Never add a paid tool without explicit approval
4. Never put API keys in code — always in environment variables
5. Never create a Stripe payment link without asking what price to charge
6. Always test an app end-to-end before activating payments
7. Always update `MEMORY.md` when learning a preference or correction
8. Always update `APPS.md` and the apps table above when an app launches
9. When credentials are missing — stop and tell the user exactly what's needed

---

## File Map

### Your personal files — in this `core/` folder
These are yours. They get personalized as you work. Never overwrite them with an update.

| File | What It Does |
|------|-------------|
| `CLAUDE.md` | This file — your agent's brain |
| `MEMORY.md` | Running memory — preferences, corrections, decisions |
| `ACCOUNTS.md` | Your tools and account statuses |
| `APPS.md` | Every app you've built |
| `skills/` | Your custom skill files |

### Shared instruction files — in the `updates/` folder
These contain build instructions and processes. Safe to replace with monthly updates.

| File | What It Does |
|------|-------------|
| `ONBOARDING.md` | First-time setup flow |
| `APP_BUILD_PROCESS.md` | How every app gets built |
| `STACK.md` | Tech options and recommendations |
| `BUSINESS_RULES.md` | Rules that keep you focused |
| `SKILLS.md` | How the skills system works |
| `README.md` | Package overview |
