# APPS.md — Ship Stack

Every app you build gets tracked here. Your agent updates this automatically when you launch something.

---

## Active Apps

*None yet — say "I want to build [your idea]" to get started.*

---

## Ideas Backlog

*Add ideas here before building. Your agent helps validate them.*

| Idea | Who It's For | Validated? | Notes |
|------|-------------|------------|-------|
| | | | |

---

## Retired / Paused Apps

*Apps you've stopped working on.*

---

## Revenue Summary

| App | Price | MRR | Total Revenue |
|-----|-------|-----|--------------|
| | | | |
| **TOTAL** | | **$0** | **$0** |

---

## App Template

*Your agent uses this format when adding a new app:*

```
### [App Name]
- **URL:** [domain]/[appname] or [appname].vercel.app
- **Repo:** github.com/[username]/[repo-name]
- **Local path:** ~/Documents/[repo-name]
- **Status:** Live / Building / Paused / Dead
- **Price:** $[X] one-time or $[X]/month or Free
- **Revenue:** $0
- **Launched:** [DATE]
- **AI stack:** [Anthropic / Groq+Tavily / other]
- **Notes:** [what it does, what's next, known issues]
```

---

## App Ideas That Work Well With This Stack

*Stuck on what to build first? These are proven ideas that fit perfectly and can be live in 48 hours.*

**Simple text tools — charge $9 one-time (use Anthropic Claude):**
- Cold Email Writer — describe your offer + target customer → ready-to-send email
- LinkedIn Bio Writer — career background → professional bio
- Job Description Writer — role details → polished job posting
- Performance Review Writer — employee notes → formal review
- Apology Email Generator — describe the situation → professional apology
- Bio Generator — any profession → clean professional bio

**Research tools — charge $9–19/month (free to run with Groq + Tavily):**
- Competitor Research Tool — enter any company → full breakdown
- Industry Trend Tracker — pick a sector → weekly analysis
- Grant Finder — describe your nonprofit → matching grant opportunities
- Reddit Trend Summarizer — any topic → what people are saying this week

**Niche tools — charge $19–49/month:**
- Real Estate Listing Writer — property details → compelling listing copy
- Menu Description Writer — dish ingredients → appetizing descriptions
- Podcast Show Notes Generator — episode topic → full show notes

**Pick one. Validate it. Build it.**
