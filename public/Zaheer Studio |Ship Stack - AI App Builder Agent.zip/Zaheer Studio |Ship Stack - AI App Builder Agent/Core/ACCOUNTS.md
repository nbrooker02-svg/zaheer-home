# ACCOUNTS.md — Ship Stack

All your tools and accounts in one place. Your agent reads this to know what you have set up and what things cost.

*Filled in and updated during onboarding and as you add tools.*

---

## Your Account Status

| Tool | Status | Details |
|------|--------|---------|
| Code storage | [active / not yet] | Platform: [YOUR_CODE_STORAGE] · Username: [YOUR_USERNAME] |
| Hosting | [active / not yet] | Platform: [YOUR_HOSTING] |
| AI API | [active / not yet] | Provider: [YOUR_AI_PROVIDER] · Credits: [AMOUNT] |
| Payments | [active / not yet] | Platform: [YOUR_PAYMENT_TOOL] |
| Domain | [active / not yet] | Domain: [YOUR_DOMAIN] · Registrar: [YOUR_REGISTRAR] |
| App scaffolding | [active / not yet] | Tool: [YOUR_SCAFFOLDING_TOOL] |

---

## Optional Tools

*Add these only when a specific app needs them. Your agent will suggest them at the right time.*

| Tool | Purpose | Status |
|------|---------|--------|
| Supabase | Database + user login | [active / not yet] |
| Resend | Send emails to users | [active / not yet] |
| Groq | Free AI for research apps | [active / not yet] |
| Tavily | Live web search for apps | [active / not yet] |
| Make.com | Automated workflows | [active / not yet] |

---

## Monthly Cost Tracker

*Update as you add tools. Goal: under $100/month until revenue starts.*

| Tool | Cost | Notes |
|------|------|-------|
| AI API | Variable | ~$0–10 at early stage |
| Payment processor | % per transaction | No monthly fee |
| Hosting | $0 | Free tier |
| Code storage | $0 | Free tier |
| Domain | ~$1–2/month | Billed annually |
| **Total** | **~$1–12/month** | |

---

## Tool Reference Guide

*What each tool does and your options. Reference this when setting up a new tool.*

---

### Code Storage

Stores your code in the cloud. Triggers automatic deployments when you push changes.

| Option | Cost | Notes |
|--------|------|-------|
| **GitHub** ⭐ recommended | Free | github.com — best integrations, most tutorials |
| GitLab | Free | gitlab.com — same concept, different interface |
| Bitbucket | Free | bitbucket.org — popular with teams |

---

### Hosting

Puts your apps on the internet. Deploys automatically from your code storage.

| Option | Cost | Notes |
|--------|------|-------|
| **Vercel** ⭐ recommended | Free tier | vercel.com — zero config, handles frontend + backend |
| Netlify | Free tier | netlify.com — almost identical to Vercel |
| Cloudflare Pages | Free tier | pages.cloudflare.com — fastest globally |
| Railway | Free tier | railway.app — better for apps needing a persistent server |

---

### AI API

Powers the intelligence inside your apps.

| Option | Cost | Best For |
|--------|------|---------|
| **Anthropic Claude** ⭐ recommended | Pay as you go | console.anthropic.com — text tasks, rewriting, generation |
| OpenAI GPT | Pay as you go | platform.openai.com — similar to Claude, personal preference |
| Google Gemini | Free tier + paid | aistudio.google.com — good free tier |
| **Groq** ⭐ free option | Free | console.groq.com — research apps, summarization, fast |

*For apps needing live web data, pair Groq with Tavily (both free).*

---

### Payments

How you collect money from users.

| Option | Fees | Notes |
|--------|------|-------|
| **Stripe** ⭐ recommended | 2.9% + 30¢/transaction | stripe.com — most flexible, lowest fees at scale |
| Lemon Squeezy | ~5% | lemonsqueezy.com — simpler setup, handles EU taxes |
| Gumroad | 10% | gumroad.com — simplest to start, highest fees |
| Paddle | ~5% | paddle.com — best for international/global sales |

---

### App Scaffolding

Builds your frontend UI from a text description. Saves hours of setup.

| Option | Cost | Notes |
|--------|------|-------|
| **Bolt.new** ⭐ recommended | Free tier | bolt.new — best overall, React + Tailwind |
| v0.dev | Free tier | v0.dev — great for specific components |
| Lovable | Free tier | lovable.dev — similar to Bolt |
| Replit | Free tier | replit.com — good for beginners |

---

### Domain Registrar

Where you buy and manage your web address.

| Option | Cost | Notes |
|--------|------|-------|
| **Namecheap** ⭐ recommended | ~$10–15/year | namecheap.com — cheapest, easy DNS |
| Cloudflare | ~$10–15/year | cloudflare.com — great DNS tools |
| Porkbun | ~$9–12/year | porkbun.com — very cheap, clean interface |

*Tips: `.com` is most trusted. `.io`, `.app`, `.co`, `.studio` are all solid. Buy only one domain until you have revenue.*
