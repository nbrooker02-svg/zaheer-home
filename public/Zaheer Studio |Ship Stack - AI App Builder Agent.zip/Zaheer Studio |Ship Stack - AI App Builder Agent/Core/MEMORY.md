# MEMORY.md — Ship Stack

Your agent reads this at the start of every session. It builds up over time — the more you use your agent, the smarter it gets.

**Your agent updates this automatically** when you correct it, share a preference, or make a decision worth remembering.

---

## About You

*Filled in during onboarding*

- **Name:** [YOUR_NAME]
- **Experience level:** [YOUR_EXPERIENCE_LEVEL]
- **Onboarding date:** [DATE]
- **First app idea:** [IDEA]

---

## Preferences

*How you like to work. Your agent saves these automatically.*

<!-- Examples:
- Prefers dark mode UI defaults
- Wants minimal comments in code
- Prefers short variable names
- Likes to review before any git push
-->

---

## Corrections

*Things your agent got wrong and should never repeat.*

<!-- Examples:
- Don't use semicolons in JavaScript
- Always mobile-first layout
- Never use placeholder copy — always write real copy
-->

---

## Decisions Made

*Key decisions so your agent never asks about them again.*

<!-- Examples:
- Using Supabase for auth on all apps that need login — decided 2024-03-15
- Charging $9 one-time for simple text tools
- Using Groq + Tavily for all research apps instead of Claude
-->

---

## App Notes

*Quirks, known issues, and reminders per app.*

<!-- Examples:
- Resume Rewriter: Vercel function sometimes times out on very long resumes — need to add chunking
- Cover Letter Gen: Users want tone options — add to v2
-->

---

## Credentials & Tools Notes

*Reminders about specific tools, keys, or account quirks.*

<!-- Examples:
- Tavily API key expires every 90 days — check if issues arise
- Git global email must be set to match GitHub or Vercel blocks deploys
- Vercel CLI must be logged in before running vercel --prod
-->
